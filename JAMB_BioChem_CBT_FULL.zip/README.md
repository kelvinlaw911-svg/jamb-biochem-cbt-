# JAMB BioChem CBT
Mobile-friendly Biology + Chemistry JAMB practice app.
## Publish with GitHub Pages
1. Create a public GitHub repository.
2. Upload `index.html`, `manifest.json`, and `.nojekyll` to the repository root.
3. Open Settings → Pages.
4. Under Build and deployment choose Deploy from a branch, then `main` and `/ (root)`.
5. Save and open the published URL. GitHub says publication can take up to 10 minutes.
